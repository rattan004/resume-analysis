// services/api.js (FINAL CORRECTED VERSION)

// 💡 CRITICAL FIX: Explicitly target the Node.js backend port (e.g., 5000)
const API_BASE_URL = "http://localhost:5000/api" 

// Helper function to handle authentication header
const getAuthHeaders = () => {
    const token = localStorage.getItem("token") || localStorage.getItem("authToken"); // Use 'token' or 'authToken'
    // Note: We avoid adding 'Content-Type': 'multipart/form-data' here, 
    // as fetch handles it automatically when 'body' is a FormData object.
    return {
        Authorization: `Bearer ${token}`,
    }
}

// Helper function to handle JSON request headers
const getJsonHeaders = () => ({
    "Content-Type": "application/json",
})


const api = {
    // --- Auth endpoints (unchanged) ---
    register: async (userData) => {
        const response = await fetch(`${API_BASE_URL}/auth/register`, {
            method: "POST",
            headers: getJsonHeaders(),
            body: JSON.stringify(userData),
        })

        if (!response.ok) {
            const error = await response.json()
            throw new Error(error.message || "Registration failed")
        }

        return response.json()
    },

    login: async (credentials) => {
        const response = await fetch(`${API_BASE_URL}/auth/login`, {
            method: "POST",
            headers: getJsonHeaders(),
            body: JSON.stringify(credentials),
        })

        if (!response.ok) {
            const error = await response.json()
            throw new Error(error.message || "Login failed")
        }

        return response.json()
    },

    getProfile: async () => {
        const response = await fetch(`${API_BASE_URL}/auth/profile`, {
            headers: getAuthHeaders(),
        })

        if (!response.ok) {
            throw new Error("Failed to fetch profile")
        }

        return response.json()
    },

    // ------------------------------------
    // --- Analysis endpoints ---
    // ------------------------------------

    /**
     * @deprecated Use uploadAndAnalyzeResume for single file analysis. 
     * This function remains for legacy multi-file upload, if applicable.
     */
    uploadFiles: async (formData) => {
        const response = await fetch(`${API_BASE_URL}/analysis/upload`, {
            method: "POST",
            headers: getAuthHeaders(),
            body: formData,
        })

        if (!response.ok) {
            const error = await response.json()
            throw new Error(error.message || "Upload failed")
        }

        return response.json()
    },
    
    /**
     * 🟢 CRITICAL FIX: Function to fetch the Job Profile by ID.
     * Maps to GET /api/analysis/job/:jobId
     * @param {string} jobId - The unique ID of the job profile to fetch.
     * @returns {Object} - Expected: { success: true, jobProfile: {...} }
     */
    getJobProfile: async (jobId) => {
        const response = await fetch(`${API_BASE_URL}/analysis/job/${jobId}`, {
            headers: getAuthHeaders(),
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            const error = data.message || 'Failed to fetch Job Profile.';
            throw new Error(error);
        }

        return data; // Returns { jobProfile, ... }
    },

    /**
     * 🎯 NEW FUNCTION (STEP 1): Uploads and analyzes the Job Description.
     * Maps to POST /api/analysis/job.
     * @param {FormData} formData - Must contain the 'jobDescription' file.
     * @returns {Object} - Expected: { success: true, jobId: '...', jobProfile: {...} }
     */
    analyzeJob: async (formData) => {
        const response = await fetch(`${API_BASE_URL}/analysis/job`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: formData,
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            const error = data.error || data.message || 'Failed to analyze Job Description.';
            throw new Error(error);
        }

        return data; // Returns { jobId, jobProfile, ... }
    },

    /**
     * 🎯 NEW FUNCTION (STEP 2 - Refactored from uploadAndAnalyzeResume): Analyzes the resume against a JD.
     * Maps to POST /api/analysis/resume.
     * @param {FormData} formData - Must contain the 'resume' file AND the 'jobId' (as a text field).
     * @returns {Object} - Expected: { success: true, candidates: [...] }
     */
    analyzeResume: async (formData) => {
        const response = await fetch(`${API_BASE_URL}/analysis/resume`, {
            method: 'POST',
            headers: getAuthHeaders(),
            body: formData,
        });

        const data = await response.json();

        if (!response.ok || !data.success) {
            const error = data.error || data.message || 'Failed to analyze resume and match against JD.';
            throw new Error(error);
        }

        // The backend returns { success: true, candidates: [candidateData] }
        return data; 
    },
    
    /**
     * 🎯 MODIFIED: Retrieves results. Currently simulates fetching from local storage 
     * since the new backend flow doesn't save to a database yet.
     */
    getAnalysisResults: async (analysisId) => {
        // 1. Try to get data from local storage (used in the temporary flow)
        const cachedData = localStorage.getItem(`analysis-${analysisId}`);
        if (cachedData) {
            // Return the structure expected by ResultsPage.jsx: { candidates: [...] }
            return JSON.parse(cachedData); 
        }
        
        // 2. Fallback to the real database endpoint
        const response = await fetch(`${API_BASE_URL}/analysis/results/${analysisId}`, {
            headers: getAuthHeaders(),
        })

        if (!response.ok) {
            throw new Error("Failed to fetch results from database or local cache expired.")
        }

        return response.json()
    },

    // --- Candidates endpoints (unchanged) ---
    getCandidates: async () => {
        const response = await fetch(`${API_BASE_URL}/candidates`, {
            headers: getAuthHeaders(),
        })

        if (!response.ok) {
            throw new Error("Failed to fetch candidates")
        }

        return response.json()
    },

    getCandidateDetails: async (candidateId) => {
        const response = await fetch(`${API_BASE_URL}/candidates/${candidateId}`, {
            headers: getAuthHeaders(),
        })

        if (!response.ok) {
            throw new Error("Failed to fetch candidate details")
        }

        return response.json()
    },

    // --- Contact endpoint (unchanged) ---
    submitContact: async (contactData) => {
        const response = await fetch(`${API_BASE_URL}/contact`, {
            method: "POST",
            headers: getJsonHeaders(),
            body: JSON.stringify(contactData),
        })

        if (!response.ok) {
            const error = await response.json()
            throw new Error(error.message || "Failed to send message")
        }

        return response.json()
    },
}

export default api