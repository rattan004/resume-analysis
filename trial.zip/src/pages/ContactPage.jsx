import { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, CircleCheck as CheckCircle } from 'lucide-react';
import api from '../services/api';
import './ContactPage.css';

const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    submitForm();
  };

  const submitForm = async () => {
    try {
      setIsSubmitting(true);
      setError('');
      
      await api.submitContact(formData);
      setIsSubmitted(true);
    } catch (err) {
      setError(err.message || 'Failed to send message. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isSubmitted) {
    return (
      <div className="contact-page">
        <div className="container">
          <div className="success-message">
            <div className="success-icon">
              <CheckCircle />
            </div>
            <h1>Message Sent Successfully!</h1>
            <p>Thank you for contacting us. We'll get back to you within 24 hours.</p>
            <button 
              className="btn btn-primary"
              onClick={() => setIsSubmitted(false)}
            >
              Send Another Message
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="contact-page">
      <div className="container">
        <div className="contact-header">
          <h1>Get in Touch</h1>
          <p>Have questions about our AI resume screening tool? We'd love to hear from you.</p>
        </div>

        <div className="contact-content">
          <div className="contact-form-section">
            <div className="contact-form-card">
              <h2>Send us a Message</h2>
              <form onSubmit={handleSubmit} className="contact-form">
                <div className="form-row">
                  <div className="form-group">
                    <label htmlFor="name">Full Name</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="email">Email Address</label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      placeholder="Enter your email"
                    />
                  </div>
                </div>
                
                <div className="form-group">
                  <label htmlFor="subject">Subject</label>
                  <input
                    type="text"
                    id="subject"
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    required
                    placeholder="What's this about?"
                  />
                </div>
                
                <div className="form-group">
                  <label htmlFor="message">Message</label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows="6"
                    placeholder="Tell us more about how we can help you..."
                  ></textarea>
                </div>
                
                {error && (
                  <div className="form-error">
                    <p>{error}</p>
                  </div>
                )}
                
                <button type="submit" className="btn btn-primary submit-btn">
                  <Send size={20} />
                  {isSubmitting ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            </div>
          </div>

          <div className="contact-info-section">
            <div className="contact-info-card">
              <h3>Contact Information</h3>
              <div className="contact-info-list">
                <div className="contact-info-item">
                  <div className="info-icon">
                    <Mail />
                  </div>
                  <div className="info-content">
                    <h4>Email</h4>
                    <p>support@airesumescreening.com</p>
                  </div>
                </div>
                
                <div className="contact-info-item">
                  <div className="info-icon">
                    <Phone />
                  </div>
                  <div className="info-content">
                    <h4>Phone</h4>
                    <p>+1 (555) 123-4567</p>
                  </div>
                </div>
                
                <div className="contact-info-item">
                  <div className="info-icon">
                    <MapPin />
                  </div>
                  <div className="info-content">
                    <h4>Address</h4>
                    <p>123 Tech Street<br />San Francisco, CA 94105</p>
                  </div>
                </div>
                
                <div className="contact-info-item">
                  <div className="info-icon">
                    <Clock />
                  </div>
                  <div className="info-content">
                    <h4>Business Hours</h4>
                    <p>Mon - Fri: 9:00 AM - 6:00 PM PST<br />Sat - Sun: Closed</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="faq-link-card">
              <h3>Quick Answers</h3>
              <p>Looking for immediate answers? Check out our FAQ section for common questions and solutions.</p>
              <a href="/faq" className="btn btn-secondary">
                View FAQ
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactPage;
