// src/components/ResultsPage.jsx
"use client"

import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Info, Mail, Briefcase, MapPin, Loader2, X, AlertTriangle } from 'lucide-react';
import api from '../services/api';
import './ResultsPage.css';

// Helper function to render a percentage circle
// NOTE: I've kept the original simple circle logic for simplicity, 
// but you might prefer the SVG-based one you introduced previously.
const ScoreCircle = ({ score, label, colorClass }) => {
    return (
        <div className="overall-score">
            <div className={`score-circle ${colorClass}`}>
                <span className="score-number">{score}%</span>
            </div>
            <p>{label}</p>
        </div>
    );
};

// Helper function to determine the color class
const getScoreColor = (score) => {
    const s = Number(score) || 0;
    if (s >= 90) return "excellent";
    if (s >= 80) return "good";
    if (s >= 65) return "fair";
    return "poor";
};

// Modal for Big Five Personality Info
const PersonalityModal = ({ onClose }) => (
    <div className="modal-overlay" onClick={onClose}>
        <div className="modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="modal-header">
                <h3>Big Five Personality Model</h3>
                <button className="modal-close" onClick={onClose}>
                    ×
                </button>
            </div>
            <div className="modal-body">
                <p>
                    The Big Five personality model (OCEAN) is a widely accepted framework in psychology that measures five
                    key personality dimensions:
                </p>

                <div className="personality-traits">
                    <div className="trait">
                        <h4 style={{ color: "var(--primary)" }}>Openness to Experience</h4>
                        <p>Creativity, curiosity, and willingness to try new things</p>
                    </div>
                    <div className="trait">
                        <h4 style={{ color: "var(--success)" }}>Conscientiousness</h4>
                        <p>Organization, discipline, and attention to detail</p>
                    </div>
                    <div className="trait">
                        <h4 style={{ color: "var(--secondary)" }}>Extraversion</h4>
                        <p>Sociability, assertiveness, and energy in social situations</p>
                    </div>
                    <div className="trait">
                        <h4 style={{ color: "var(--accent)" }}>Agreeableness</h4>
                        <p>Cooperation, trust, and consideration for others</p>
                    </div>
                    <div className="trait">
                        <h4 style={{ color: "var(--error)" }}>Neuroticism</h4>
                        <p>Emotional stability and stress management (lower scores are better)</p>
                    </div>
                </div>

                <div className="how-it-works">
                    <h4>How it works:</h4>
                    <p>
                        Our AI analyzes resume language patterns to infer personality traits, then compares them against the
                        ideal profile for your job role to determine cultural and behavioral fit.
                    </p>
                </div>
            </div>
        </div>
    </div>
);


const ResultsPage = () => {
    const [candidateData, setCandidateData] = useState(null);
    const [jobProfile, setJobProfile] = useState(null);
    const [showPersonalityModal, setShowPersonalityModal] = useState(false);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    
    const [searchParams] = useSearchParams();
    const analysisId = searchParams.get('analysisId'); // Corresponds to jobId
    const candidateId = searchParams.get('candidateId'); // Corresponds to candidate's _id

    useEffect(() => {
        if (analysisId && candidateId) {
            fetchCandidateDetails(analysisId, candidateId);
        } else {
            // Revert to original flow's simpler ID lookup if the new parameters are missing
            const fallbackAnalysisId = searchParams.get("analysisId") || localStorage.getItem("currentAnalysisId");
            if (fallbackAnalysisId) {
                // Rerun a simplified version of the original fetch (assuming it returns all candidate data)
                fetchOriginalCandidateData(fallbackAnalysisId);
            } else {
                setError('Missing analysis ID or candidate ID in the URL/storage.');
                setLoading(false);
            }
        }
    }, [analysisId, candidateId]);

    // This function implements the advanced fetching logic you proposed in your second version
    const fetchCandidateDetails = async (aId, cId) => {
        try {
            setLoading(true);
            setError('');
            
            // NOTE: For simplicity, I'm skipping the localStorage cache logic here 
            // and going straight to the API calls as you defined in your new fetch structure.

            // Fetch candidate details and job profile concurrently
            const [candidateDetails, jobData] = await Promise.all([
                api.getCandidateDetails(cId),
                api.getJobProfile(aId)
            ]);

            if (candidateDetails && jobData) {
                setCandidateData(candidateDetails);
                setJobProfile(jobData);
            } else {
                throw new Error("Candidate or Job Profile data could not be retrieved.");
            }

        } catch (err) {
            const errorMessage = err.response?.data?.message || err.message || "Failed to load detailed analysis.";
            setError(errorMessage);
            console.error(err);
        } finally {
            setLoading(false);
        }
    };
    
    // Fallback logic from your original code (assuming old API structure)
    const fetchOriginalCandidateData = async (aId) => {
        try {
            setLoading(true);
            const data = await api.getAnalysisResults(aId);
            if (data.candidates && data.candidates.length > 0) {
                // Set the first candidate as in your original component
                setCandidateData(data.candidates[0]); 
                // We don't have jobProfile separately here, but we can live without it for the simple case
            } else {
                setError("No candidate data found");
            }
        } catch (err) {
            setError(err.message || "Failed to load candidate data (Original API failed)");
        } finally {
            setLoading(false);
        }
    }


    if (loading) {
        return (
            <div className="results-page loading">
                <div className="container">
                    <div className="loading-message">
                        <Loader2 size={32} className="spinner" />
                        <p>Loading candidate details...</p>
                    </div>
                </div>
            </div>
        );
    }

    if (error && !candidateData) {
        return (
            <div className="results-page error">
                <div className="container">
                    <div className="error-message">
                        <AlertTriangle size={32} />
                        <h1>Error</h1>
                        <p>{error}</p>
                        <Link to="/ranking" className="btn btn-primary">
                            Back to Rankings
                        </Link>
                    </div>
                </div>
            </div>
        );
    }
    
    // Use the candidateData (renamed from candidate in your second version)
    const candidate = candidateData; 
    
    // Destructure required fields with fallbacks
    const {
        name = 'N/A',
        email = 'N/A',
        overallMatch = 0,
        skillsMatch = 0, // Assume this is present in the candidate object
        personalityFit = 0, // Assume this is present in the candidate object
        quickStats = {}, // Assume this is present in the candidate object
        skillsBreakdown = {}, // Assume this is present in the candidate object
        personalityProfile = {}, // Assume this is present in the candidate object
        // Add other fields from your second version that are useful but not in the original UI:
        location,
        jobTitle,
    } = candidate || {};

    // Get the job title from jobProfile if available, otherwise use candidate's jobTitle or fallback.
    const jobTitleDisplay = jobProfile?.title || jobTitle || 'Target Role';

    // Helper to render skill tags
    const renderSkillTags = (skillsArray, className) => (
        <div className="skill-tags">
            {skillsArray?.map((skill, index) => (
                <span key={index} className={`skill-tag ${className}`}>
                    {skill}
                </span>
            ))}
        </div>
    );


    return (
        <div className="results-page">
            <div className="container">
                <Link to="/ranking" className="back-button">
                    <ArrowLeft />
                    Return
                </Link>

                {/* Header Section */}
                <div className="results-header">
                    <div className="candidate-info">
                        <h1>{name}</h1>
                        <p className="candidate-email">{email}</p>
                        <p className="job-title-display">Matching against: {jobTitleDisplay}</p>
                    </div>
                    <ScoreCircle 
                        score={overallMatch} 
                        label="Overall Match" 
                        colorClass={getScoreColor(overallMatch)} 
                    />
                </div>

                {/* Main Content */}
                <div className="results-content">
                    <div className="results-left">
                        
                        {/* Score Breakdown */}
                        <div className="score-section card">
                            <h2>Score Breakdown</h2>

                            <div className="score-item">
                                <div className="score-label">
                                    <h3>Skills Match</h3>
                                    <p>Technical and functional skill alignment</p>
                                </div>
                                <div className={`score-value skills ${getScoreColor(skillsMatch)}`}>{skillsMatch}%</div>
                            </div>

                            <div className="score-item">
                                <div className="score-label">
                                    <h3>Personality Fit</h3>
                                    <p>Big five personality trait alignment</p>
                                </div>
                                <div className={`score-value personality ${getScoreColor(personalityFit)}`}>{personalityFit}%</div>
                            </div>
                        </div>

                        {/* Personality Profile */}
                        <div className="personality-section card">
                            <div className="personality-header">
                                <h2>Personality Profile</h2>
                                <button className="info-button" onClick={() => setShowPersonalityModal(true)}>
                                    <Info size={16} />
                                </button>
                            </div>

                            <div className="personality-traits-list">
                                {Object.entries(personalityProfile).length > 0 ? (
                                    Object.entries(personalityProfile).map(([trait, data]) => (
                                        <div key={trait} className="personality-trait">
                                            <div className="trait-header">
                                                <span className="trait-name">{trait.charAt(0).toUpperCase() + trait.slice(1)}</span>
                                                <span className="trait-match">{data.match || 0}% Match</span>
                                            </div>
                                            <div className="trait-scores">
                                                <span>Candidate: {data.candidate || 'N/A'}</span>
                                                <span>Ideal: {data.ideal || 'N/A'}</span>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <p>No detailed personality trait data available.</p>
                                )}
                            </div>
                        </div>
                    </div>

                    <div className="results-right">
                        {/* Quick Stats */}
                        <div className="quick-stats card">
                            <h2>Quick Stats</h2>
                            <div className="stat-item">
                                <span>Perfect Skill Match</span>
                                <span className="stat-number">{quickStats.perfectSkillMatch || 0}</span>
                            </div>
                            <div className="stat-item">
                                <span>Partial Skill Match</span>
                                <span className="stat-number">{quickStats.partialSkillMatch || 0}</span>
                            </div>
                            <div className="stat-item">
                                <span>Missing Skills</span>
                                <span className="stat-number">{quickStats.missingSkills || 0}</span>
                            </div>
                        </div>

                        {/* Skills Match Details */}
                        <div className="skills-details card">
                            <div className="skills-header">
                                <h2>Skills Match</h2>
                                <span className={`overall-match ${getScoreColor(skillsMatch)}`}>{skillsMatch}%</span>
                            </div>
                            <p>Overall Match</p>

                            <div className="skills-breakdown">
                                <div className="skill-category">
                                    <h4>Perfect Matches</h4>
                                    {renderSkillTags(skillsBreakdown.perfectMatches, 'perfect')}
                                </div>

                                <div className="skill-category">
                                    <h4>Partial Matches</h4>
                                    {renderSkillTags(skillsBreakdown.partialMatches, 'partial')}
                                </div>

                                <div className="skill-category">
                                    <h4>Missing Skills</h4>
                                    {renderSkillTags(skillsBreakdown.missingSkills, 'missing')}
                                </div>
                            </div>
                        </div>
                        
                        {/* The Resume Preview section from your second version can be optionally placed here 
                        if candidateData.resumePreviewUrl is available. */}
                        {candidate?.resumePreviewUrl && (
                            <div className="resume-preview-section card">
                                <h3>Resume Preview</h3>
                                <div className="resume-iframe-container">
                                    <iframe 
                                        src={candidate.resumePreviewUrl} 
                                        title="Resume Preview" 
                                        frameBorder="0" 
                                        allowFullScreen
                                    ></iframe>
                                </div>
                                <p className="download-link">
                                    <a href={candidate.resumePreviewUrl} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                                        Download Original Resume
                                    </a>
                                </p>
                            </div>
                        )}
                    </div>
                </div>
            </div>

            {/* Personality Info Modal */}
            {showPersonalityModal && <PersonalityModal onClose={() => setShowPersonalityModal(false)} />}
        </div>
    );
}

export default ResultsPage;