// server.js
import express from "express"
import cors from "cors"
import path from "path"
import fs from "fs"
import rateLimit from "express-rate-limit"
import { fileURLToPath } from "url"
import dotenv from "dotenv"
import multer from "multer" 
import { spawn } from "child_process" 
import { Types } from 'mongoose'; 

// 🎯 NEW IMPORTS for MongoDB
import connectDB from './config/db.js'; 
import JobProfile from './models/JobProfile.js'; 
import Candidate from './models/Candidate.js'; // Assuming you have this model defined

// Configure dotenv
dotenv.config()

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const app = express()

// General rate limiting
const generalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, 
  max: 100, 
  message: {
    message: "Too many requests from this IP, please try again later.",
  },
  standardHeaders: true,
  legacyHeaders: false,
})

app.use(generalLimiter)

// CORS configuration
app.use(
  cors({
    origin: process.env.FRONTEND_URL || "http://localhost:5173",
    credentials: true,
  }),
)

// Body parsing middleware
app.use(express.json({ limit: "10mb" }))
app.use(express.urlencoded({ extended: true, limit: "10mb" }))

// Define uploads directory path and create it if it doesn't exist
const uploadsDir = path.join(__dirname, "uploads")
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true })
}

app.use("/uploads", express.static(uploadsDir))

// Multer Configuration for file uploads
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadsDir);
    },
    filename: (req, file, cb) => {
        cb(null, `${Date.now()}-${file.originalname}`);
    },
});

const upload = multer({ 
    storage: storage,
    limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
    fileFilter: (req, file, cb) => {
        if (file.mimetype === 'application/pdf') {
            cb(null, true);
        } else {
            cb(new Error('Only PDF files are allowed'), false);
        }
    }
});


// --- DATA TRANSFORMATION LOGIC (ROBUST NaN FIX APPLIED) ---
function transformData(rawData, requirements) {
    const candidateSkills = rawData.skills || [];
    const requiredSkills = requirements.REQUIRED_SKILLS || []; 
    const idealPersonality = requirements.IDEAL_PERSONALITY || {}; 
    
    // --- Helper function for robust number check ---
    const getSafeScore = (score) => Number.isFinite(score) ? score : 0;

    // --- Skill Match Calculation ---
    const perfectMatches = candidateSkills.filter(skill => requiredSkills.includes(skill));
    const requiredButMissing = requiredSkills.filter(skill => !candidateSkills.includes(skill));
    const extraSkills = candidateSkills.filter(skill => !requiredSkills.includes(skill)); 
    
    const requiredCount = requiredSkills.length;
    
    // Ensure division by zero is avoided for skillsMatch
    const skillsMatchRaw = (requiredCount > 0) 
        ? (perfectMatches.length / requiredCount) * 100
        : 0; 
        
    const skillsMatch = Math.min(100, Math.round(skillsMatchRaw));


    // --- Personality Fit Calculation (CRITICALLY FIXED) ---
    let personalityFitSum = 0;
    let personalityProfile = {};
    const traits = Object.keys(idealPersonality);
    const traitCount = traits.length;
    
    traits.forEach(trait => {
        // Get raw score, default to undefined if personality block is missing
        const rawCandidateScore = rawData.personality ? rawData.personality[trait] : undefined;
        
        // Use the safe function to guarantee a number
        const candidateScore = getSafeScore(rawCandidateScore);
        
        const idealScore = idealPersonality[trait] || 0;
        
        // Match = 100 - absolute distance from ideal score
        const matchScore = 100 - Math.abs(candidateScore - idealScore);
        
        // Add match score to sum (guaranteed non-NaN)
        personalityFitSum += Math.max(0, matchScore);
        
        personalityProfile[trait] = {
            candidate: candidateScore,
            ideal: idealScore,
            match: Math.max(0, matchScore), 
        };
    });
    
    // Ensure division by zero is avoided and result is a number
    const personalityFitRaw = (traitCount > 0)
        ? (personalityFitSum / traitCount)
        : 0; 
        
    // Ensure final scores are guaranteed numbers
    const personalityFit = getSafeScore(Math.round(personalityFitRaw));
    
    // --- Overall Score Calculation ---
    const overallMatchRaw = (skillsMatch * 0.6) + (personalityFit * 0.4);
    
    // Ensure final scores are guaranteed numbers
    const overallMatch = getSafeScore(Math.round(overallMatchRaw));

    // Final Structure for Storage/React Component
    return {
        name: rawData.name,
        email: rawData.email,
        jobTitle: rawData.jobTitle,
        summary: rawData.summary,
        
        // Scores are guaranteed to be finite numbers (0-100)
        overallMatch, 
        skillsMatch,
        personalityFit,
        
        quickStats: {
            perfectSkillMatch: perfectMatches.length,
            partialSkillMatch: extraSkills.length, 
            missingSkills: requiredButMissing.length,
        },
        skillsBreakdown: {
            perfectMatches: perfectMatches,
            partialMatches: extraSkills, 
            missingMatches: requiredButMissing,
        },
        personalityProfile,
    };
}

// -----------------------------------------------------------------------------

// --- 1. API Endpoint to analyze Job Description (JD) ---
app.post('/api/analysis/job', upload.single('jobDescription'), (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No job description file provided.' });
    }

    const filePath = req.file.path;
    const pythonScriptPath = path.join(__dirname, 'job_analyzer.py'); 

    const pythonProcess = spawn('python', [pythonScriptPath, filePath]);

    let pythonOutput = '';
    let pythonError = '';

    pythonProcess.stdout.on('data', (data) => {
        pythonOutput += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
        pythonError += data.toString();
    });

    pythonProcess.on('close', async (code) => { 
        // Clean up the uploaded file immediately
        fs.unlink(filePath, (err) => {
            if (err) console.error('Failed to delete uploaded JD file:', err);
        });

        if (code !== 0 || (pythonError && !pythonOutput)) {
            console.error(`JD Python script failed (Code ${code}): ${pythonError}`);
            return res.status(500).json({ 
                success: false, 
                message: 'Failed to run job analysis script.', 
                details: pythonError || 'Unknown error.'
            });
        }
        
        try {
            const jsonMatch = pythonOutput.trim().match(/({[\s\S]*})$/);
            
            if (!jsonMatch) {
                console.error('JD script output error:', pythonOutput);
                return res.status(500).json({ success: false, message: 'Invalid output from job analysis script.' });
            }
            
            const result = JSON.parse(jsonMatch[1]);

            if (!result.success) {
                return res.status(400).json({ success: false, message: result.error || 'Job analysis failed.' });
            }

            // SAVE THE IDEAL PROFILE TO MONGODB ATLAS
            const jobId = new Types.ObjectId().toString(); 
            
            const jobProfileData = {
                jobId: jobId,
                REQUIRED_SKILLS: result.data.REQUIRED_SKILLS,
                IDEAL_PERSONALITY: result.data.IDEAL_PERSONALITY,
                jobTitle: result.data.jobTitle || 'Extracted Job Description' 
            };

            const savedProfile = await JobProfile.create(jobProfileData);

            // Send back the ID and the extracted data
            res.json({ 
                success: true, 
                jobId: savedProfile.jobId, // Use the ID from the saved document
                jobProfile: {
                    REQUIRED_SKILLS: savedProfile.REQUIRED_SKILLS,
                    IDEAL_PERSONALITY: savedProfile.IDEAL_PERSONALITY
                }
            });

        } catch (e) {
            console.error('Processing JD failed:', e);
            res.status(500).json({ success: false, message: 'Internal error during JD data processing or database save.' });
        }
    });
});


// 🟢 FIX FOR 404 ERROR: Add the missing GET route for Job Profile details
app.get("/api/analysis/job/:jobId", async (req, res) => {
    try {
        const jobId = req.params.jobId;

        const jobProfileDoc = await JobProfile.findOne({ jobId: jobId });

        if (!jobProfileDoc) {
            // NOTE: Returning a standard 404/expired message for security
            return res.status(404).json({ success: false, message: 'Job profile not found or expired.' });
        }

        // Return the required data structure for the ResultsPage
        res.json({
            success: true,
            jobProfile: {
                jobId: jobProfileDoc.jobId,
                jobTitle: jobProfileDoc.jobTitle,
                REQUIRED_SKILLS: jobProfileDoc.REQUIRED_SKILLS,
                IDEAL_PERSONALITY: jobProfileDoc.IDEAL_PERSONALITY
            }
        });

    } catch (e) {
        console.error('Failed to retrieve job profile:', e);
        res.status(500).json({ success: false, message: 'Internal error during database retrieval.' });
    }
});


// --- 2. API Endpoint for Resume Analysis ---
app.post("/api/analysis/resume", upload.single('resume'), async (req, res) => {
    const jobId = req.body.jobId; // Expecting the jobId from the frontend
    
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No resume file provided.' });
    }
    
    // 1. FETCH IDEAL PROFILE FROM MONGODB
    const jobProfileDoc = await JobProfile.findOne({ jobId: jobId });

    if (!jobProfileDoc) {
        // Clean up resume file
        fs.unlink(req.file.path, (err) => {
             if (err) console.error('Failed to delete uploaded resume file:', err);
        });
        return res.status(400).json({ success: false, message: 'Job requirements not found or expired. Please upload the Job Description first.' });
    }

    const jobRequirements = {
        REQUIRED_SKILLS: jobProfileDoc.REQUIRED_SKILLS,
        IDEAL_PERSONALITY: jobProfileDoc.IDEAL_PERSONALITY
    };

    const filePath = req.file.path;
    const pythonScriptPath = path.join(__dirname, 'resume_analyzer.py');

    // 2. EXECUTE PYTHON SCRIPT 
    const pythonProcess = spawn('python', [pythonScriptPath, filePath]);
    
    let pythonOutput = '';
    let pythonError = '';

    pythonProcess.stdout.on('data', (data) => {
        pythonOutput += data.toString();
    });

    pythonProcess.stderr.on('data', (data) => {
        pythonError += data.toString();
    });

    pythonProcess.on('close', async (code) => {
        // Clean up the uploaded file asynchronously
        fs.unlink(filePath, (err) => {
            if (err) console.error('Failed to delete uploaded file:', err);
        });

        if (code !== 0 || (pythonError && !pythonOutput)) {
            console.error(`Python script failed (Code ${code}): ${pythonError}`);
            return res.status(500).json({ 
                success: false, 
                message: 'Failed to run resume analysis script.', 
                details: pythonError || 'Unknown error. Check python installation and script dependencies.'
            });
        }
        
        try {
            const jsonMatch = pythonOutput.trim().match(/({[\s\S]*})$/);
            
            if (!jsonMatch) {
                console.error("Python output did not contain valid JSON:", pythonOutput);
                return res.status(500).json({ success: false, message: 'Invalid output from analysis script.' });
            }
            
            const pythonResult = JSON.parse(jsonMatch[1]);

            if (!pythonResult.success) {
                return res.status(400).json({ success: false, message: pythonResult.error || 'Analysis failed.' });
            }

            // 3. TRANSFORM DATA using the DYNAMIC jobRequirements (Uses fixed logic for NaN)
            const analyzedData = transformData(pythonResult.data, jobRequirements);

            // 4. PREPARE AND SAVE DATA TO MONGODB
            const candidateDocument = {
                jobId: jobId,
                ...analyzedData
            };
            
            // CRITICAL FIX: Save the candidate data to MongoDB
            const savedCandidate = await Candidate.create(candidateDocument);

            // 5. SEND FINAL DATA: Use the MongoDB _id as the unique candidate ID
            res.json({ 
                success: true, 
                // The frontend expects the unique ID here
                candidateId: savedCandidate._id.toString(), 
                candidates: [{ 
                    // Attach the MongoDB ID to the returned candidate object (for RankingPage.jsx)
                    _id: savedCandidate._id.toString(), 
                    ...analyzedData 
                }] 
            });

        } catch (e) {
            console.error('Processing failed:', e);
            res.status(500).json({ success: false, message: 'Internal error during data processing or database save.' });
        }
    });
});


// Import only the necessary, existing routes
import analysisRoutes from "./routes/analysis.js"
import authRoutes from "./routes/auth.js"
import contactRoutes from "./routes/contact.js" 

// Use routes
app.use("/api/auth", authRoutes)
app.use("/api/analysis", analysisRoutes) 
app.use("/api/contact", contactRoutes)


// Health check endpoint
app.get("/api/health", (req, res) => {
  res.json({
    status: "OK",
    message: "AI Resume Screening API is running",
    timestamp: new Date().toISOString(),
  })
})

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("Error:", err)
  
  // Multer file type error handling
  if (err.message === 'Only PDF files are allowed') {
    return res.status(415).json({ message: err.message });
  }

  // Check for Multer file size error
  if (err.code === 'LIMIT_FILE_SIZE') {
    return res.status(413).json({ message: "File size too large (max 10MB)." });
  }
  
  res.status(500).json({
    message: "Internal server error",
    error: process.env.NODE_ENV === "development" ? err.message : "Something went wrong",
  })
})

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: "API endpoint not found" })
})

const PORT = process.env.PORT || 5000

// Final Step: Connect to the database, then start the server
connectDB().then(() => {
    app.listen(PORT, () => {
        console.log(`🚀 Server running on port ${PORT}`)
        console.log(`📊 API Health: http://localhost:${PORT}/api/health`)
        console.log(`🌐 Frontend: ${process.env.FRONTEND_URL || "http://localhost:5173"}`)
    });
}).catch(err => {
    console.error("Failed to start server due to DB connection error:", err);
});