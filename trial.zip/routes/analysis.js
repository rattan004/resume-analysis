// routes/analysis.js
import express from "express"
import auth from "../middleware/auth.js"
import fs from "fs" 
import multer from "multer" 
import path from "path" 
import { fileURLToPath } from "url" 
import { extractResumeDataWithPython } from "../utils/pythonRunner.js" // PYTHON RUNNER UTILITY

const router = express.Router()

// --- 💡 Multer Configuration (Self-Contained) ---
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename) 
// Define the uploads directory path relative to the project root
const uploadsDir = path.join(__dirname, "..", "uploads") 

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadsDir)
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
  },
})

const upload = multer({
  storage: storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req, file, cb) => {
    const allowedMimes = [
      "text/plain",
      "application/pdf",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ]
    if (allowedMimes.includes(file.mimetype)) {
      cb(null, true)
    } else {
      cb(new Error("Invalid file type. Only PDF, DOC, DOCX, and TXT files are allowed."))
    }
  },
})
// --- End Multer Configuration ---


// In-memory storage for analysis (temporary mock data store)
const analyses = []
let analysisIdCounter = 1

// 1. POST /api/analysis/upload - Uploads files, runs Python, and returns the ID
router.post("/upload", auth, upload.fields([
    { name: "resume", maxCount: 1 },
    { name: "jobDescription", maxCount: 1 },
]), async (req, res) => {
  let resumeFile = null
  let jobDescriptionFile = null
  
  try {
    if (!req.files || !req.files.resume) {
      return res.status(400).json({ message: "Resume file is required" })
    }

    const analysisId = analysisIdCounter++
    resumeFile = req.files.resume[0]
    jobDescriptionFile = req.files?.jobDescription?.[0]
    
    // --- Python Execution Logic ---
    let resumeData = {}
    try {
      resumeData = await extractResumeDataWithPython(resumeFile.path)
    } catch (parseError) {
      console.error("Resume parsing error (Python runner):", parseError.message)
      return res.status(500).json({ 
          message: "Failed to process resume file with the parsing engine.", 
          error: parseError.message 
      })
    }
    // --- End Python Execution Logic ---

    // Create analysis record with extracted data
    const analysis = {
      id: analysisId,
      userId: req.user.userId,
      createdAt: new Date(),
      status: "completed",
      resumeFile: resumeFile.filename,
      resumePath: resumeFile.path,
      jobDescriptionFile: jobDescriptionFile?.filename || null,
      jobDescriptionPath: jobDescriptionFile?.path || null,
      extractedData: resumeData,
    }

    analyses.push(analysis)

    res.status(201).json({
      message: "Files uploaded and analyzed successfully",
      analysisId: analysisId,
      data: resumeData, // Send data back for immediate display if needed
    })
  } catch (error) {
    console.error("Upload error:", error)
    res.status(500).json({ message: "Server error during upload", error: error.message })
  } finally {
      // 💡 Cleanup logic for temporary files
      const cleanupFile = (file) => {
          if (file && file.path && fs.existsSync(file.path)) {
              // fs.unlink is async, but we don't await it, just log errors
              fs.unlink(file.path, (err) => {
                  if (err) console.error(`Cleanup failed for file ${file.path}:`, err);
              });
          }
      }
      cleanupFile(resumeFile);
      cleanupFile(jobDescriptionFile);
  }
})

// 2. POST /api/analysis/analyze/:analysisId - This route is redundant if upload does analysis, 
//    but is kept for a potential future multi-step workflow.
router.post("/analyze/:analysisId", auth, async (req, res) => {
  try {
    const analysisId = Number.parseInt(req.params.analysisId)
    const analysis = analyses.find((a) => a.id === analysisId && a.userId === req.user.userId)

    if (!analysis) {
      return res.status(404).json({ message: "Analysis not found" })
    }

    analysis.status = "completed"
    analysis.completedAt = new Date()

    res.json({
      message: "Analysis completed",
      analysisId: analysisId,
      status: "completed",
      data: analysis.extractedData,
    })
  } catch (error) {
    console.error("Analysis error:", error)
    res.status(500).json({ message: "Server error during analysis" })
  }
})

// 3. GET /api/analysis/results/:analysisId - Fetches the already-computed data
router.get("/results/:analysisId", auth, async (req, res) => {
  try {
    const analysisId = Number.parseInt(req.params.analysisId)
    const analysis = analyses.find((a) => a.id === analysisId && a.userId === req.user.userId)

    if (!analysis) {
      return res.status(404).json({ message: "Analysis not found" })
    }

    const extractedData = analysis.extractedData || {}

    // Mocking a complete candidate object using extracted data
    const candidate = {
      id: analysisId,
      rank: 1,
      name: extractedData.name || "Candidate",
      email: extractedData.email || "candidate@email.com",
      skills: 85, 
      personality: 88, 
      overallMatch: 86,
      quickStats: {
        perfectSkillMatch: extractedData.skills.length,
        partialSkillMatch: 2,
        missingSkills: 1,
      },
      skillsBreakdown: {
        perfectMatches: extractedData.skills || [],
        partialMatches: [],
        missingSkills: [],
      },
    }

    res.json({
      analysisId: analysisId,
      status: analysis.status,
      candidates: [candidate],
    })
  } catch (error) {
    console.error("Results error:", error)
    res.status(500).json({ message: "Server error fetching results" })
  }
})

export default router