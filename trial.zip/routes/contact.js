import express from "express"
import { body, validationResult } from "express-validator"

const router = express.Router()

// In-memory storage for contact messages (replace with database in production)
const contactMessages = []

// Submit contact form
router.post(
  "/",
  [
    body("name").trim().isLength({ min: 2 }).withMessage("Name must be at least 2 characters"),
    body("email").isEmail().normalizeEmail().withMessage("Please provide a valid email"),
    body("subject").trim().isLength({ min: 3 }).withMessage("Subject must be at least 3 characters"),
    body("message").trim().isLength({ min: 10 }).withMessage("Message must be at least 10 characters"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({
          message: "Validation failed",
          errors: errors.array(),
        })
      }

      const { name, email, subject, message } = req.body

      // Store contact message
      const contactMessage = {
        id: contactMessages.length + 1,
        name,
        email,
        subject,
        message,
        createdAt: new Date(),
        status: "new",
      }

      contactMessages.push(contactMessage)

      res.status(201).json({
        message: "Message sent successfully. We will get back to you soon!",
        messageId: contactMessage.id,
      })
    } catch (error) {
      console.error("Contact error:", error)
      res.status(500).json({ message: "Server error sending message" })
    }
  },
)

export default router
